#include <iostream>
#include <GL/gl.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <math.h>
#include<windows.h>
#include<mmsystem.h>
#include<math.h>>
# define PI   3.14159265358979323846

using namespace std;

float _run = 0.0;
float _run1 = 0.0;
float _run2 = 0.0;
float _run3 = 0.0;
float _rain = 0.0;
float _nt = 0.0;
float _ang_tri = 0.0;
char text[] = "";


bool onOff;
bool frd = false;
bool bck = false;

bool rainday = false;
bool night = false;



void Sprint( float x, float y, char *st)
{
    int l,i;


    l=strlen( st ); // see how many characters are in text string.
    glColor3f(1.0,0.0,0.0);
    //glDisable(GL_LIGHTING);
    glRasterPos2f( x, y); // location to start printing text
    for( i=0; i < l; i++) // loop until i is greater then l
    {
       glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, st[i]);

    }
}


void init(){

	glClearColor(0.0,0.5,0.8,1.0);
	gluOrtho2D(-200.0,200.0,-300.0,300.0);

}
GLubyte house1fullbuildingR=255;GLubyte house1fullbuildingG=138;GLubyte house1fullbuildingB=101;
GLubyte house1whiteR=255, house1whiteG=255, house1whiteB=255, house1whiteAlpha=255; //whitecolor;
GLubyte house1blackR=0, house1blackG=0, house1blackB=0, house1blackAlpha=0;
GLubyte house1doorR=255, house1doorG=87, house1doorB=34;
GLubyte building1windowR=240, building1windowG=244, building1windowB=195;

GLubyte ashR=178, ashG=186, ashB=187, ashAlpha=255; //ash color rect of relling
GLubyte brownR=248, brownG=196, brownB=113, brownAlpha=255; //brown color lines of relling;
GLubyte whiteR=255, whiteG=255, whiteB=255, whiteAlpha=255; //whitecolor;



void display(){
	glClear(GL_COLOR_BUFFER_BIT);

///Cloud

    glPushMatrix();
    glTranslatef(_run3, 0.0, 0.0);



    glPushMatrix();
    glTranslatef(-100, 200, 0);

    glBegin(GL_POLYGON);
    glColor3f(1.0, 1.0, 1.0);
	for(int i=0;i<200;i++)
	{
		float pi=3.1416;
		float A=(i*2*pi)/200;
		float r=20;
		float x = r * cos(A);
		float y = r * sin(A);
		glVertex2f(x,y );
	}
	glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-80, 220, 0);

    glBegin(GL_POLYGON);
    glColor3f(1.0, 1.0, 1.0);
	for(int i=0;i<200;i++)
	{
		float pi=3.1416;
		float A=(i*2*pi)/200;
		float r=15;
		float x = r * cos(A);
		float y = r * sin(A);
		glVertex2f(x,y );
	}
	glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-80, 180, 0);

    glBegin(GL_POLYGON);
    glColor3f(1.0, 1.0, 1.0);
	for(int i=0;i<200;i++)
	{
		float pi=3.1416;
		float A=(i*2*pi)/200;
		float r=20;
		float x = r * cos(A);
		float y = r * sin(A);
		glVertex2f(x,y );
	}
	glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-70, 200, 0);

    glBegin(GL_POLYGON);
    glColor3f(1.0, 1.0, 1.0);
	for(int i=0;i<200;i++)
	{
		float pi=3.1416;
		float A=(i*2*pi)/200;
		float r=20;
		float x = r * cos(A);
		float y = r * sin(A);
		glVertex2f(x,y );
	}
	glEnd();
    glPopMatrix();


//cloud 2
    glPushMatrix();
    glTranslatef(-10, 140, 0);
    glPushMatrix();
    glTranslatef(0, 130, 0);

    glBegin(GL_POLYGON);
    glColor3f(1.0, 1.0, 1.0);
	for(int i=0;i<200;i++)
	{
		float pi=3.1416;
		float A=(i*2*pi)/200;
		float r=20;
		float x = r * cos(A);
		float y = r * sin(A);
		glVertex2f(x,y );
	}
	glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-5, 120, 0);

    glBegin(GL_POLYGON);
    glColor3f(1.0, 1.0, 1.0);
	for(int i=0;i<200;i++)
	{
		float pi=3.1416;
		float A=(i*2*pi)/200;
		float r=30;
		float x = r * cos(A);
		float y = r * sin(A);
		glVertex2f(x,y );
	}
	glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(15, 150, 0);

    glBegin(GL_POLYGON);
    glColor3f(1.0, 1.0, 1.0);
	for(int i=0;i<200;i++)
	{
		float pi=3.1416;
		float A=(i*2*pi)/200;
		float r=30;
		float x = r * cos(A);
		float y = r * sin(A);
		glVertex2f(x,y );
	}
	glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(30, 130, 0);

    glBegin(GL_POLYGON);
    glColor3f(1.0, 1.0, 1.0);
	for(int i=0;i<200;i++)
	{
		float pi=3.1416;
		float A=(i*2*pi)/200;
		float r=30;
		float x = r * cos(A);
		float y = r * sin(A);
		glVertex2f(x,y );
	}
	glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(20, 130, 0);

    glBegin(GL_POLYGON);
    glColor3f(1.0, 1.0, 1.0);
	for(int i=0;i<200;i++)
	{
		float pi=3.1416;
		float A=(i*2*pi)/200;
		float r=20;
		float x = r * cos(A);
		float y = r * sin(A);
		glVertex2f(x,y );
	}
	glEnd();
    glPopMatrix();

     glPushMatrix();
    glTranslatef(-35, 160, 0);

    glBegin(GL_POLYGON);
    glColor3f(1.0, 1.0, 1.0);
	for(int i=0;i<200;i++)
	{
		float pi=3.1416;
		float A=(i*2*pi)/200;
		float r=30;
		float x = r * cos(A);
		float y = r * sin(A);
		glVertex2f(x,y );
	}
	glEnd();
    glPopMatrix();
    glPopMatrix();


    glPopMatrix();


    /// middle Hills


    glPushMatrix();
    glTranslatef(50,3,0);
    glScalef(1.6,1.3,0);
    glBegin(GL_TRIANGLES);
    glColor4ub(129,199,132,255);
    glVertex2f(0,20);
    glColor4ub(27,94,32,255);
    glVertex2f(-20,-10);
    glVertex2f(20,-10);
    glEnd();
    glPopMatrix();

        glPushMatrix();
    glTranslatef(20,-4,0);
    glScalef(0.9,0.6,0);
    glBegin(GL_TRIANGLES);
    glColor4ub(174,213,129,255);
    glVertex2f(0,20);
    glColor4ub(85,139,47,255);
    glVertex2f(-20,-10);
    glVertex2f(20,-10);
    glEnd();
    glPopMatrix();

   ///1st hills



   glPushMatrix();
    glTranslatef(-150,3,0);
    glScalef(1.6,1.3,0);
    glBegin(GL_TRIANGLES);
    glColor4ub(129-100,199-100,132-100,255);
    glVertex2f(0,20);
    glColor4ub(27-27,94-27,32-27,255);
    glVertex2f(-20,-10);
    glVertex2f(20,-10);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-170,-1,0);
    glScalef(1,0.9,0);
    glBegin(GL_TRIANGLES);
    glColor4ub(129-100,199-100,132-100,255);
    glVertex2f(0,20);
    glColor4ub(85-47,139-47,47-47,255);
    glVertex2f(-20,-10);
    glVertex2f(20,-10);
    glEnd();
    glPopMatrix();
///last hill


    glPushMatrix();
    glTranslatef(120,-4,0);//
    glScalef(0.9,0.6,0);
    glBegin(GL_TRIANGLES);
    glColor4ub(174-100,213-100,129-100,255);
    glVertex2f(0,20);
    glColor4ub(85-47,139-47,47-47,255);
    glVertex2f(-20,-10);
    glVertex2f(20,-10);
    glEnd();
    glPopMatrix();
///

    glPushMatrix();
    glTranslatef(150,3,0);
    glScalef(1.6,1.3,0);
    glBegin(GL_TRIANGLES);
    glColor4ub(129-100,199-100,132-100,255);
    glVertex2f(0,20);
    glColor4ub(27-27,94-27,32-27,255);
    glVertex2f(-20,-10);
    glVertex2f(20,-10);
    glEnd();
    glPopMatrix();

///
    glPushMatrix();
    glTranslatef(170,-1,0);
    glScalef(1,0.9,0);
    glBegin(GL_TRIANGLES);
    glColor4ub(129-100,199-100,132-100,255);
    glVertex2f(0,20);
    glColor4ub(85-47,139-47,47-47,255);
    glVertex2f(-20,-10);
    glVertex2f(20,-10);
    glEnd();
    glPopMatrix();


 ///upperland

    glColor4ub(255, 245, 157,255);
    glBegin(GL_QUADS);
    glVertex2f(200,-10);
    glVertex2f(-200,-10);

    glColor4ub(97, 201, 133,150);
    glVertex2f(-200,-80);
    glVertex2f(200,-80);
    glEnd();

    glColor4ub(255-100, 245-100, 157-100,255);
    glBegin(GL_QUADS);
    glVertex2f(200,-10);
    glVertex2f(-200,-10);

    glColor4ub(97-50, 201-50, 133-50,150);
    glVertex2f(-200,-80);
    glVertex2f(200,-80);
    glEnd();






 ///BUILDING left


    glBegin(GL_QUADS);//full building
    glColor3ub(house1fullbuildingR , house1fullbuildingG, house1fullbuildingB );
    glVertex2f(-140,-10);
    glVertex2f(-100,-10);
    glVertex2f(-100,50);
    glVertex2f(-140,50);
    glEnd();

    glBegin(GL_LINES);//lower part line
    glColor3ub( 109, 76, 65);
    glVertex2f(-140,10);
    glVertex2f(-100,10);
    glEnd();

    glBegin(GL_LINES);//lower part
    glColor3ub(house1blackR,house1blackG,house1blackB);
    glVertex2f(-135,10);
    glVertex2f(-135,-10);
    glEnd();

    glBegin(GL_LINES);//lower part
    glColor3ub(house1blackR,house1blackG,house1blackB);
    glVertex2f(-130,10);
    glVertex2f(-130,-10);
    glEnd();

    glBegin(GL_LINES);//house1
    glColor3ub(house1blackR,house1blackG,house1blackB);
    glVertex2f(-125,10);
    glVertex2f(-125,-10);
    glEnd();

    glBegin(GL_LINES);//lower part
    glColor3ub(house1blackR,house1blackG,house1blackB);
    glVertex2f(-120,10);
    glVertex2f(-120,-10);
    glEnd();

    glBegin(GL_LINES);////lower part
    glColor3ub(house1blackR,house1blackG,house1blackB);
    glVertex2f(-115,10);
    glVertex2f(-115,-10);
    glEnd();

    glBegin(GL_LINES);////lower part
    glColor3ub(house1blackR,house1blackG,house1blackB);
    glVertex2f(-110,10);
    glVertex2f(-110,-10);
    glEnd();

    glBegin(GL_LINES);////lower part
    glColor3ub(house1blackR,house1blackG,house1blackB);
    glVertex2f(-105,10);
    glVertex2f(-105,-10);
    glEnd();

    glBegin(GL_LINES);////lower part
    glColor3ub(house1blackR,house1blackG,house1blackB);
    glVertex2f(-100,10);
    glVertex2f(-100,-10);
    glEnd();

    glBegin(GL_LINES);////lower part
    glColor3ub(house1blackR,house1blackG,house1blackB);
    glVertex2f(-140,10);
    glVertex2f(-140,-10);
    glEnd();

    glBegin(GL_LINES);////lower part
    glColor3ub(house1blackR,house1blackG,house1blackB);
    glVertex2f(-140,5);
    glVertex2f(-100,5);
    glEnd();

    glBegin(GL_LINES);////lower part
    glColor3ub(house1blackR,house1blackG,house1blackB);
    glVertex2f(-140,0);
    glVertex2f(-100,0);
    glEnd();

    glBegin(GL_LINES);////lower part
    glColor3ub(house1blackR,house1blackG,house1blackB);
    glVertex2f(-140,-5);
    glVertex2f(-100,-5);
    glEnd();

    glBegin(GL_LINES);////lower part
    glColor3ub(house1blackR,house1blackG,house1blackB);
    glVertex2f(-140,-5);
    glVertex2f(-100,-5);
    glEnd();

    glBegin(GL_LINES);////upper part line
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-140,10);
    glVertex2f(-140,50);
    glEnd();

    glBegin(GL_LINES);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-135,10);
    glVertex2f(-135,50);
    glEnd();

    glBegin(GL_LINES);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-130,10);
    glVertex2f(-130,50);
    glEnd();

    glBegin(GL_LINES);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-125,10);
    glVertex2f(-125,50);
    glEnd();

    glBegin(GL_LINES);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-120,10);
    glVertex2f(-120,50);
    glEnd();
    glBegin(GL_LINES);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-115,10);
    glVertex2f(-115,50);
    glEnd();

    glBegin(GL_LINES);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-110,10);
    glVertex2f(-110,50);
    glEnd();

    glBegin(GL_LINES);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-105,10);
    glVertex2f(-105,50);
    glEnd();

    glBegin(GL_LINES);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-100,10);
    glVertex2f(-100,50);
    glEnd();

    glBegin(GL_QUADS);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-140,10);
    glVertex2f(-140,50);
    glEnd();

    glBegin(GL_QUADS);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-140,9);
    glVertex2f(-100,9);
    glVertex2f(-100,11);
    glVertex2f(-140,11);
    glEnd();

    glBegin(GL_QUADS);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-140,15);
    glVertex2f(-100,15);
    glVertex2f(-100,17);
    glVertex2f(-140,17);
    glEnd();

    glBegin(GL_QUADS);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-140,21);
    glVertex2f(-100,21);
    glVertex2f(-100,23);
    glVertex2f(-140,23);
    glEnd();

    glBegin(GL_QUADS);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-140,27);
    glVertex2f(-100,27);
    glVertex2f(-100,29);
    glVertex2f(-140,29);
    glEnd();

    glBegin(GL_QUADS);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-140,33);
    glVertex2f(-100,33);
    glVertex2f(-100,35);
    glVertex2f(-140,35);
    glEnd();

    glBegin(GL_QUADS);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-140,39);
    glVertex2f(-100,39);
    glVertex2f(-100,41);
    glVertex2f(-140,41);
    glEnd();

    glBegin(GL_QUADS);//upper part line showing window
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-140,45);
    glVertex2f(-100,45);
    glVertex2f(-100,47);
    glVertex2f(-140,47);
    glEnd();

    glBegin(GL_QUADS);//upper part white border
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-140,50);
    glVertex2f(-100,50);
    glVertex2f(-100,53);
    glVertex2f(-140,53);
    glEnd();

    glBegin(GL_QUADS);//upper part white border
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-135,53);
    glVertex2f(-105,53);
    glVertex2f(-105,57);
    glVertex2f(-135,57);
    glEnd();

    glBegin(GL_QUADS);//upper part white border
    glColor3ub(house1whiteR,house1whiteG,house1whiteB);
    glVertex2f(-125,57);
    glVertex2f(-115,57);
    glVertex2f(-115,60);
    glVertex2f(-125,60);
    glEnd();

    glBegin(GL_QUADS);//door
    glColor3ub(house1doorR, house1doorG, house1doorB);
    glVertex2f(-128,-10);
    glVertex2f(-117,-10);
    glVertex2f(-117,0);
    glVertex2f(-128,0);
    glEnd();

    glBegin(GL_QUADS);//door white frame
    glColor3ub(255, 255, 255);
    glVertex2f(-126,-10);
    glVertex2f(-128,-10);
    glVertex2f(-128,0);
    glVertex2f(-126,0);
    glEnd();

    glBegin(GL_QUADS);//door white frame
    glColor3ub(255, 255, 255);
    glVertex2f(-121,-10);
    glVertex2f(-122,-10);
    glVertex2f(-122,0);
    glVertex2f(-121,0);
    glEnd();

    glBegin(GL_QUADS);//door white frame
    glColor3ub(255, 255, 255);
    glVertex2f(-115,-10);
    glVertex2f(-117,-10);
    glVertex2f(-117,0);
    glVertex2f(-115,0);
    glEnd();

    glBegin(GL_QUADS);//door white frame
    glColor3ub(255, 255, 255);
    glVertex2f(-128,1);
    glVertex2f(-115,1);
    glVertex2f(-115,0);
    glVertex2f(-128,0);
    glEnd();

///BUILDING1 middle


   glBegin(GL_QUADS);
    glColor3ub(255,128,0) ;

    glVertex2f(-80,-40);
    glVertex2f(-40,-40);
    glColor3ub(255,255,0) ;  ///bulding1
    glVertex2f(-40,40);
    glVertex2f(-80,40);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(153,76,0) ;

    glVertex2f(-82,50);  //up part1
    glVertex2f(-80,40);

    glVertex2f(-40,40);
    glVertex2f(-38,50);
    glEnd();


    glBegin(GL_QUADS);
    glColor3ub(255,128,0) ;

    glVertex2f(-75,50);
    glVertex2f(-45,50);
    glColor3ub(255,255,0) ;  ///up part1
    glVertex2f(-45,65);
    glVertex2f(-75,65);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(153,76,0) ;

    glVertex2f(-75,65);  //up part1
    glVertex2f(-45,65);

    glVertex2f(-43,75);
    glVertex2f(-78,75);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255,128,0) ;

    glVertex2f(-95,-20);
    glVertex2f(-25,-20);
    glColor3ub(255,255,0) ;  ///down part1
    glVertex2f(-25,-40);
    glVertex2f(-95,-40);
    glEnd();


    glBegin(GL_QUADS);
    glColor3ub(153,76,0) ;
    glVertex2f(-93,-23);
    glVertex2f(-83,-23);
    ///down window part1
    glVertex2f(-83,-40);
    glVertex2f(-93,-40);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153,76,0) ;
    glVertex2f(-81,-23);
    glVertex2f(-71,-23);
    ///down window part1
    glVertex2f(-71,-40);
    glVertex2f(-81,-40);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153,76,0) ;
    glVertex2f(-69,-23);
    glVertex2f(-59,-23);
    ///down window part1
    glVertex2f(-59,-40);
    glVertex2f(-69,-40);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153,76,0) ;
    glVertex2f(-57,-23);
    glVertex2f(-47,-23);
    ///down window part1
    glVertex2f(-47,-40);
    glVertex2f(-57,-40);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153,76,0) ;
    glVertex2f(-45,-23);
    glVertex2f(-35,-23);
    ///down window part1
    glVertex2f(-35,-40);
    glVertex2f(-45,-40);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153,76,0) ;
    glVertex2f(-35,-23);
    glVertex2f(-45,-23);
    ///down window part1
    glVertex2f(-25,-40);
    glVertex2f(-43,-40);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153,76,0) ;
    glVertex2f(-40,20);
    glVertex2f(-25,20);
    ///right side1
    glVertex2f(-25,-20);
    glVertex2f(-40,-20);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-37,18);
    glVertex2f(-28,18);
    glColor3ub(255,255,204) ;       ///right side1 window
    glVertex2f(-28,10);
    glVertex2f(-37,10);
    glEnd();

//glTranslatef(0,0,0);
    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-37,6);
    glVertex2f(-28,6);
    glColor3ub(255,255,204) ;       ///right side1 window
    glVertex2f(-28,-2);
    glVertex2f(-37,-2);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-37,-6);
    glVertex2f(-28,-6);
    glColor3ub(255,255,204) ;       ///right side1 window
    glVertex2f(-28,-14);
    glVertex2f(-37,-14);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153,76,0) ;
    glVertex2f(-95,20);
    glVertex2f(-80,20);
    /// left side1
    glVertex2f(-80,-20);
    glVertex2f(-95,-20);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-93,18);
    glVertex2f(-83,18);
    glColor3ub(255,255,204) ;       ///left side1 window
    glVertex2f(-83,10);
    glVertex2f(-93,10);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-93,6);
    glVertex2f(-83,6);
    glColor3ub(255,255,204) ;       ///left side1 window
    glVertex2f(-83,-2);
    glVertex2f(-93,-2);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-93,-6);
    glVertex2f(-83,-6);
    glColor3ub(255,255,204) ;       ///left side1 window
    glVertex2f(-83,-14);
    glVertex2f(-93,-14);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-78,35);
    glVertex2f(-68,35);
    glColor3ub(255,255,204) ;       ///building window
    glVertex2f(-68,25);
    glVertex2f(-78,25);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-78,23);
    glVertex2f(-68,23);
    glColor3ub(255,255,204) ;       ///building window
    glVertex2f(-68,13);
    glVertex2f(-78,13);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-78,11);
    glVertex2f(-68,11);
    glColor3ub(255,255,204) ;       ///building window
    glVertex2f(-68,1);
    glVertex2f(-78,1);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-78,-2);
    glVertex2f(-68,-2);
    glColor3ub(255,255,204) ;       ///building window
    glVertex2f(-68,-12);
    glVertex2f(-78,-12);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-64,35);
    glVertex2f(-54,35);
    glColor3ub(255,255,204) ;       ///building window
    glVertex2f(-54,25);
    glVertex2f(-64,25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-64,23);
    glVertex2f(-54,23);
    glColor3ub(255,255,204) ;       ///building window
    glVertex2f(-54,13);
    glVertex2f(-64,13);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-64,11);
    glVertex2f(-54,11);
    glColor3ub(255,255,204) ;       ///building window
    glVertex2f(-54,1);
    glVertex2f(-64,1);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-64,-2);
    glVertex2f(-54,-2);
    glColor3ub(255,255,204) ;       ///building window
    glVertex2f(-54,-12);
    glVertex2f(-64,-12);
    glEnd();


    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-50,35);
    glVertex2f(-40,35);
    glColor3ub(255,255,204) ;       ///building window
    glVertex2f(-40,25);
    glVertex2f(-50,25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-50,23);
    glVertex2f(-40,23);
    glColor3ub(255,255,204) ;       ///building window
    glVertex2f(-40,13);
    glVertex2f(-50,13);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-50,11);
    glVertex2f(-40,11);
    glColor3ub(255,255,204) ;       ///building window
    glVertex2f(-40,1);
    glVertex2f(-50,1);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-50,-2);
    glVertex2f(-40,-2);
    glColor3ub(255,255,204) ;       ///building window
    glVertex2f(-40,-12);
    glVertex2f(-50,-12);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-71,62);
    glVertex2f(-63,62);
    glColor3ub(255,255,204) ;       ///upbuilding window
    glVertex2f(-63,52);
    glVertex2f(-71,52);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,255) ;
    glVertex2f(-57,62);
    glVertex2f(-49,62);
    glColor3ub(255,255,204) ;       ///upbuilding window
    glVertex2f(-49,52);
    glVertex2f(-57,52);
    glEnd();


///building2 right

   glBegin(GL_QUADS);

    glColor3ub(255,255,204) ;
    glVertex2f(-20,-40);
    glVertex2f(20,-40);
//glColor3ub(255,255,204) ;       ///building2
    glVertex2f(20,40);
    glVertex2f(-20,40);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,37);
    glVertex2f(20,37);
//glColor3ub(255,255,204) ;       ///building2
    glVertex2f(20,35);
    glVertex2f(-20,35);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,32);
    glVertex2f(20,32);
//glColor3ub(255,255,204) ;       ///building2
    glVertex2f(20,30);
    glVertex2f(-20,30);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,27);
    glVertex2f(20,27);
//glColor3ub(255,255,204) ;       ///building2
    glVertex2f(20,25);
    glVertex2f(-20,25);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,22);
    glVertex2f(20,22);
//glColor3ub(255,255,204) ;       ///building2
    glVertex2f(20,20);
    glVertex2f(-20,20);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(229,255,204) ;
    glVertex2f(-10,20);
    glVertex2f(10,20);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(10,-40);
    glVertex2f(-10,-40);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-8,18);
    glVertex2f(-5,18);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-5,15);
    glVertex2f(-8,15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-4,18);
    glVertex2f(-1,18);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-1,15);
    glVertex2f(-4,15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-8,13);
    glVertex2f(-5,13);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-5,10);
    glVertex2f(-8,10);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-4,13);
    glVertex2f(-1,13);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-1,10);
    glVertex2f(-4,10);
    glEnd();


    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-8,8);
    glVertex2f(-5,8);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-5,5);
    glVertex2f(-8,5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-4,8);
    glVertex2f(-1,8);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-1,5);
    glVertex2f(-4,5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-8,3);
    glVertex2f(-5,3);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-5,0);
    glVertex2f(-8,0);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-4,3);
    glVertex2f(-1,3);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-1,0);
    glVertex2f(-4,0);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-8,-2);
    glVertex2f(-5,-2);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-5,-5);
    glVertex2f(-8,-5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-4,-2);
    glVertex2f(-1,-2);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-1,-5);
    glVertex2f(-4,-5);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-8,-7);
    glVertex2f(-5,-7);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-5,-10);
    glVertex2f(-8,-10);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-4,-7);
    glVertex2f(-1,-7);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-1,-10);
    glVertex2f(-4,-10);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-8,-12);
    glVertex2f(-5,-12);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-5,-15);
    glVertex2f(-8,-15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-4,-12);
    glVertex2f(-1,-12);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-1,-15);
    glVertex2f(-4,-15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-8,-17);
    glVertex2f(-5,-17);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-5,-20);
    glVertex2f(-8,-20);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-4,-17);
    glVertex2f(-1,-17);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-1,-20);
    glVertex2f(-4,-20);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-8,-22);
    glVertex2f(-5,-22);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-5,-25);
    glVertex2f(-8,-25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-4,-22);
    glVertex2f(-1,-22);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-1,-25);
    glVertex2f(-4,-25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-8,-27);
    glVertex2f(-5,-27);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-5,-30);
    glVertex2f(-8,-30);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-4,-27);
    glVertex2f(-1,-27);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(-1,-30);
    glVertex2f(-4,-30);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-8,-32);
    glVertex2f(-1,-32);
//glColor3ub(255,255,204) ;
    ///building2windowdoor
    glVertex2f(-1,-40);
    glVertex2f(-8,-40);
    glEnd();



    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(2,13);
    glVertex2f(5,13);
//glColor3ub(255,255,204) ;
    ///building2window right
    glVertex2f(5,10);
    glVertex2f(2,10);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(6,13);
    glVertex2f(9,13);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(9,10);
    glVertex2f(6,10);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(2,18);
    glVertex2f(5,18);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(5,15);
    glVertex2f(2,15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(6,18);
    glVertex2f(9,18);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(9,15);
    glVertex2f(6,15);
    glEnd();




    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(2,8);
    glVertex2f(5,8);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(5,5);
    glVertex2f(2,5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(6,8);
    glVertex2f(9,8);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(9,5);
    glVertex2f(6,5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(2,3);
    glVertex2f(5,3);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(5,0);
    glVertex2f(2,0);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(6,3);
    glVertex2f(9,3);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(9,0);
    glVertex2f(6,0);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(2,-2);
    glVertex2f(5,-2);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(5,-5);
    glVertex2f(2,-5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(6,-2);
    glVertex2f(9,-2);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(9,-5);
    glVertex2f(6,-5);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(2,-7);
    glVertex2f(5,-7);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(5,-10);
    glVertex2f(2,-10);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(6,-7);
    glVertex2f(9,-7);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(9,-10);
    glVertex2f(6,-10);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(2,-12);
    glVertex2f(5,-12);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(5,-15);
    glVertex2f(2,-15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(6,-12);
    glVertex2f(9,-12);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(9,-15);
    glVertex2f(6,-15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(2,-17);
    glVertex2f(5,-17);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(5,-20);
    glVertex2f(2,-20);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(6,-17);
    glVertex2f(9,-17);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(9,-20);
    glVertex2f(6,-20);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(2,-22);
    glVertex2f(5,-22);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(5,-25);
    glVertex2f(2,-25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(6,-22);
    glVertex2f(9,-22);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(9,-25);
    glVertex2f(6,-25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(2,-27);
    glVertex2f(5,-27);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(5,-30);
    glVertex2f(2,-30);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(6,-27);
    glVertex2f(9,-27);
//glColor3ub(255,255,204) ;
    ///building2window
    glVertex2f(9,-30);
    glVertex2f(6,-30);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(2,-32);
    glVertex2f(9,-32);
//glColor3ub(255,255,204) ;
    ///building2windowdoor
    glVertex2f(9,-40);
    glVertex2f(2,-40);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,17);
    glVertex2f(-10,17);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(-10,15);
    glVertex2f(-20,15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,12);
    glVertex2f(-10,12);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(-10,10);
    glVertex2f(-20,10);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,7);
    glVertex2f(-10,7);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(-10,5);
    glVertex2f(-20,5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,2);
    glVertex2f(-10,2);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(-10,0);
    glVertex2f(-20,0);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,-3);
    glVertex2f(-10,-3);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(-10,-5);
    glVertex2f(-20,-5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,-8);
    glVertex2f(-10,-8);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(-10,-10);
    glVertex2f(-20,-10);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,-13);
    glVertex2f(-10,-13);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(-10,-15);
    glVertex2f(-20,-15);
    glEnd();


    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,-18);
    glVertex2f(-10,-18);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(-10,-20);
    glVertex2f(-20,-20);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,-23);
    glVertex2f(-10,-23);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(-10,-25);
    glVertex2f(-20,-25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(-20,-28);
    glVertex2f(-10,-28);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(-10,-30);
    glVertex2f(-20,-30);
    glEnd();


    glBegin(GL_QUADS);
    glColor3ub(0,0,0) ;
    glVertex2f(-20,-33);
    glVertex2f(-10,-33);
    glColor3ub(255,255,204) ;
    ///building2door
    glVertex2f(-10,-40);
    glVertex2f(-20,-40);
    glEnd();


    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(10,17);
    glVertex2f(20,17);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(20,15);
    glVertex2f(10,15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(10,12);
    glVertex2f(20,12);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(20,10);
    glVertex2f(10,10);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(10,7);
    glVertex2f(20,7);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(20,5);
    glVertex2f(10,5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(10,2);
    glVertex2f(20,2);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(20,0);
    glVertex2f(10,0);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(10,-3);
    glVertex2f(20,-3);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(20,-5);
    glVertex2f(10,-5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(10,-8);
    glVertex2f(20,-8);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(20,-10);
    glVertex2f(10,-10);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(10,-13);
    glVertex2f(20,-13);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(20,-15);
    glVertex2f(10,-15);
    glEnd();


    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(10,-18);
    glVertex2f(20,-18);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(20,-20);
    glVertex2f(10,-20);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(10,-23);
    glVertex2f(20,-23);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(20,-25);
    glVertex2f(10,-25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,76) ;
    glVertex2f(10,-28);
    glVertex2f(20,-28);
//glColor3ub(255,255,204) ;
    ///building2
    glVertex2f(20,-30);
    glVertex2f(10,-30);
    glEnd();


    glBegin(GL_QUADS);
    glColor3ub(0,0,0) ;
    glVertex2f(10,-33);
    glVertex2f(20,-33);
    glColor3ub(255,255,204) ;
    ///building2door
    glVertex2f(20,-40);
    glVertex2f(10,-40);
    glEnd();




//Road

    glColor4ub( 128, 139, 150,255);
    glBegin(GL_QUADS);
    glVertex2f(200,-80);
    glVertex2f(-200,-80);
    glVertex2f(-200,-158);
    glVertex2f(200,-158);
    glEnd();
///lake

glColor4ub( 109,213,255,255);
    glBegin(GL_QUADS);
    glVertex2f(200,-158);
    glVertex2f(-200,-158);
    glColor4ub( 11,185,255,255);
    glVertex2f(-200,-300);
    glVertex2f(200,-300);
    glEnd();

    ashAlpha=255;
    brownAlpha=255;
    whiteAlpha=255;

 ///LAKE RAILING

 glColor4ub( ashR, ashG, ashB, ashAlpha);
    glRectd(-200,-158,200,-162);


    for(int i=-200; i<202; i+=10)
    {
        glColor4ub( brownR, brownG, brownB, brownAlpha );
        glBegin(GL_LINES);
        glVertex2f(i,-154);
        glVertex2f(i,-162);
        glEnd();

        glColor4ub(255,255,0, whiteAlpha);
        glBegin(GL_POINTS);
        glVertex2f(i,-156);
        glEnd();
    }


  ///RAILING 2ND

    glEnable(GL_POINT_SMOOTH);
    glLineWidth(3);//stick width
    glPointSize(6);
    for(int i=-200; i<202; i+=10)
    {
        glColor4ub( brownR, brownG, brownB, brownAlpha );
        glBegin(GL_LINES);
        glVertex2f(i,-140);
        glVertex2f(i,-158);
        glEnd();

        glColor4ub(255,255,255, whiteAlpha);//light
        glBegin(GL_POINTS);
        glVertex2f(i,-140);
        glEnd();
    }

    glLineWidth(1);
    glColor4ub( brownR, brownG, brownB, brownAlpha );
    glBegin(GL_LINES);
    glVertex2f(-200,-157);
    glVertex2f(200,-157);
    glEnd();

    glBegin(GL_LINES);
    glVertex2f(-200,-155);
    glVertex2f(200,-155);
    glEnd();

    glBegin(GL_LINES);
    glVertex2f(-200,-153);
    glVertex2f(200,-153);
    glEnd();


  ///TREES


    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(-30,-40);
    glColor3ub(139,195,74);
    glVertex2f(-50,-60);
    glVertex2f(-10,-60);
    glEnd();
    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(-30,-30);
    glColor3ub(139,195,74);
    glVertex2f(-50,-50);
    glVertex2f(-10,-50);
    glEnd();

    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(-30,-20);
    glColor3ub(139,195,74);
    glVertex2f(-50,-40);
    glVertex2f(-10,-40);
    glEnd();

   glColor3ub(109,76,65);
    glBegin(GL_QUADS);
    glVertex2f(-29,-80);

    glVertex2f(-31,-80);
    glVertex2f(-31,-60);
    glVertex2f(-29,-60);
    glEnd();


    ///tree2

    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(-140,-40);
    glColor3ub(139,195,74);
    glVertex2f(-160,-60);
    glVertex2f(-120,-60);
    glEnd();
    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(-140,-30);
    glColor3ub(139,195,74);
    glVertex2f(-160,-50);
    glVertex2f(-120,-50);
    glEnd();

    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(-140,-20);
    glColor3ub(139,195,74);
    glVertex2f(-160,-40);
    glVertex2f(-120,-40);
    glEnd();

   glColor3ub(109,76,65);
    glBegin(GL_QUADS);
    glVertex2f(-139,-80);

    glVertex2f(-141,-80);
    glVertex2f(-141,-60);
    glVertex2f(-139,-60);
    glEnd();
///tree3
     glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(-170,-20);
    glColor3ub(139,195,74);
    glVertex2f(-190,-40);
    glVertex2f(-150,-40);
    glEnd();
    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(-170,-10);
    glColor3ub(139,195,74);
    glVertex2f(-190,-30);
    glVertex2f(-150,-30);
    glEnd();

    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(-170,-10);
    glColor3ub(139,195,74);
    glVertex2f(-190,-20);
    glVertex2f(-150,-20);
    glEnd();

   glColor3ub(109,76,65);
    glBegin(GL_QUADS);
    glVertex2f(-169,-60);

    glVertex2f(-171,-60);
    glVertex2f(-171,-40);
    glVertex2f(-169,-40);
    glEnd();

   ///tree4


   glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(170,-20);
    glColor3ub(139,195,74);
    glVertex2f(190,-40);
    glVertex2f(150,-40);
    glEnd();
    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(170,-10);
    glColor3ub(139,195,74);
    glVertex2f(190,-30);
    glVertex2f(150,-30);
    glEnd();

    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(170,-10);
    glColor3ub(139,195,74);
    glVertex2f(190,-20);
    glVertex2f(150,-20);
    glEnd();

   glColor3ub(109,76,65);
    glBegin(GL_QUADS);
    glVertex2f(169,-60);

    glVertex2f(171,-60);
    glVertex2f(171,-40);
    glVertex2f(169,-40);
    glEnd();

///tree5

glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(140,-40);
    glColor3ub(139,195,74);
    glVertex2f(160,-60);
    glVertex2f(120,-60);
    glEnd();
    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(140,-30);
    glColor3ub(139,195,74);
    glVertex2f(160,-50);
    glVertex2f(120,-50);
    glEnd();

    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(140,-20);
    glColor3ub(139,195,74);
    glVertex2f(160,-40);
    glVertex2f(120,-40);
    glEnd();

   glColor3ub(109,76,65);
    glBegin(GL_QUADS);
    glVertex2f(139,-80);

    glVertex2f(141,-80);
    glVertex2f(141,-60);
    glVertex2f(139,-60);
    glEnd();

///tree6

glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(110,-20);
    glColor3ub(139,195,74);
    glVertex2f(130,-40);
    glVertex2f(90,-40);
    glEnd();
    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(110,-10);
    glColor3ub(139,195,74);
    glVertex2f(130,-30);
    glVertex2f(90,-30);
    glEnd();

    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(110,-10);
    glColor3ub(139,195,74);
    glVertex2f(130,-20);
    glVertex2f(90,-20);
    glEnd();

   glColor3ub(109,76,65);
    glBegin(GL_QUADS);
    glVertex2f(109,-60);

    glVertex2f(111,-60);
    glVertex2f(111,-40);
    glVertex2f(109,-40);
    glEnd();

    //NEW CAR

glPushMatrix();
glTranslatef(_run, 0.0, 0.0);

glPushMatrix();
glTranslatef(200, 2, 0);
    glColor3ub(255,20,20);//car1
glBegin(GL_QUADS);
 glVertex2f(120,-105);
 glVertex2f(70,-105);
 glVertex2f(70,-82);
 glVertex2f(120,-82);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(200, 2, 0);
     glColor3ub(255,255, 255);//car1
glBegin(GL_QUADS);
 glVertex2f(80,-92);
 glVertex2f(75,-92);
 glVertex2f(75,-87);
 glVertex2f(80,-87);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(200, 2, 0);
      glColor3ub(255,255, 255);//car1
glBegin(GL_QUADS);
 glVertex2f(90,-92);
 glVertex2f(85,-92);
 glVertex2f(85,-87);
 glVertex2f(90,-87);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(200, 2, 0);
       glColor3ub(255,255, 255);//car1
glBegin(GL_QUADS);
 glVertex2f(100,-92);
 glVertex2f(95,-92);
 glVertex2f(95,-87);
 glVertex2f(100,-87);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(200, 2, 0);
        glColor3ub(255,255, 255);//car1
glBegin(GL_QUADS);
 glVertex2f(110,-92);
 glVertex2f(105,-92);
 glVertex2f(105,-87);
 glVertex2f(110,-87);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(200, 2, 0);

 int j;

	GLfloat a=108.0f; GLfloat b=-108.0f; GLfloat radiuss =8.0f;    //car1
	int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePii = 2.0f * PI;
    glColor3ub(0,0,0);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a, b); // center of circle
		for(j = 0; j <= triangleAmount;j++) {
			glVertex2f(
		            a + (radiuss * cos(j *  twicePii / triangleAmount)),
			    b + (radiuss * sin(j * twicePii / triangleAmount))
			);
		}

glEnd();
glPopMatrix();

glPushMatrix();
glTranslatef(200, 2, 0);
int k;

	GLfloat c=83.0f; GLfloat d=-108.0f; GLfloat radiusss =8.0f;//car1
	int triangleAmounttt = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePiii = 2.0f * PI;
    glColor3ub(0, 0, 0);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(c, d); // center of circle
		for(k = 0; k <= triangleAmounttt;k++) {
			glVertex2f(
		            c + (radiusss * cos(k *  twicePiii / triangleAmounttt)),
			    d + (radiuss * sin(k * twicePiii / triangleAmounttt)));}
    glEnd();
    glPopMatrix();

    glPushMatrix();
glTranslatef(200, 2, 0);
    int n;
    	GLfloat w=83.0f; GLfloat x=-108.0f; GLfloat radiusswx =5.0f;    //car1
	int triangleAmountwx = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePiiwx = 2.0f * PI;
    glColor3ub(255,255,255);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(w, x); // center of circle
		for(n = 0; n <= triangleAmountwx;n++) {
			glVertex2f(
		            w + (radiusswx * cos(n *  twicePiiwx / triangleAmountwx)),
			    x + (radiusswx * sin(n * twicePiiwx / triangleAmountwx))
			);
		}

glEnd();
glPopMatrix();

    glPushMatrix();
glTranslatef(200, 2, 0);
    int o;
    	GLfloat y=108.0f; GLfloat z=-108.0f; GLfloat radiussyz =5.0f;    //car1
	int triangleAmountyz = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePiiyz = 2.0f * PI;
    glColor3ub(255,255,255);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(y, z); // center of circle
		for(o = 0; o <= triangleAmountyz;o++) {
			glVertex2f(
		            y + (radiussyz * cos(o *  twicePiiyz / triangleAmountyz)),
			    z + (radiussyz * sin(o * twicePiiyz / triangleAmountyz))
			);
		}

glEnd();
glPopMatrix();


    glPopMatrix();


    //Car2


    glPushMatrix();
glTranslatef(_run1, 0.0, 0.0);

glPushMatrix();
glTranslatef(-400, 25, 0);
           glColor3ub(0,0,255);
glBegin(GL_QUADS);
 glVertex2f(180,-150);
 glVertex2f(150,-150);
 glVertex2f(150,-135);
 glVertex2f(180,-135);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(-400, 25, 0);
            glColor3ub(0,0,255);
glBegin(GL_QUADS);
 glVertex2f(175,-135);
 glVertex2f(155,-135);
 glVertex2f(160,-125);
 glVertex2f(170,-125);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(-400, 25, 0);
             glColor3ub(0,255,255);
glBegin(GL_QUADS);
 glVertex2f(160,-133);
 glVertex2f(157,-133);
 glVertex2f(157,-136);
 glVertex2f(160,-136);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(-400, 25, 0);
              glColor3ub(0,255,255);
glBegin(GL_QUADS);
 glVertex2f(165,-133);
 glVertex2f(161,-133);
 glVertex2f(161,-136);
 glVertex2f(165,-136);
 glEnd();
 glPopMatrix();

glPushMatrix();
glTranslatef(-400, 25, 0);
              glColor3ub(0,255,255);
glBegin(GL_QUADS);
 glVertex2f(170,-133);
 glVertex2f(166,-133);
 glVertex2f(166,-136);
 glVertex2f(170,-136);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(-400, 25, 0);
 int l;

	GLfloat e=170.0f; GLfloat f=-152.0f; GLfloat radiuss2 =5.0f;    //car1
	int triangleAmount2 = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePii2 = 2.0f * PI;
    glColor3ub(0,0,0);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(e, f); // center of circle
		for(l = 0; l <= triangleAmount2;l++) {
			glVertex2f(
		            e + (radiuss2 * cos(l *  twicePii2 / triangleAmount2)),
			    f + (radiuss2 * sin(l * twicePii2 / triangleAmount2))
			);
		}

glEnd();
glPopMatrix();

glPushMatrix();
glTranslatef(-400, 25, 0);
int m;

	GLfloat g=160.0f; GLfloat h=-152.0f; GLfloat radiusss4 =5.0f;//car1
	int triangleAmounttt4 = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePiii4 = 2.0f * PI;
    glColor3ub(0, 0, 0);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(g, h); // center of circle
		for(m = 0; m <= triangleAmounttt4;m++) {
			glVertex2f(
		            g + (radiusss4 * cos(m *  twicePiii4 / triangleAmounttt4)),
			    h + (radiusss4 * sin(m * twicePiii4 / triangleAmounttt4)));}
    glEnd();
    glPopMatrix();
    glPopMatrix();

    //SHIP1

    glPushMatrix();
glTranslatef(_run1, 0.0, 0.0);

glPushMatrix();
glTranslatef(-200, 25, 0);

       glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(150,-240);
 glVertex2f(110,-240);
 glVertex2f(105,-225);
 glVertex2f(155,-225);
 glEnd();
     glPopMatrix();

     glPushMatrix();
glTranslatef(-200, 25, 0);
       glColor3ub(128,128,128);
glBegin(GL_QUADS);
 glVertex2f(153,-225);
 glVertex2f(107,-225);
 glVertex2f(107,-212);
 glVertex2f(153,-212);
 glEnd();
 glPopMatrix();

glPushMatrix();
glTranslatef(-200, 25, 0);
       glColor3ub(128,128,128);
glBegin(GL_QUADS);
 glVertex2f(150,-212);
 glVertex2f(110,-212);
 glVertex2f(110,-204);
 glVertex2f(150,-204);
 glEnd();
 glPopMatrix();

glPushMatrix();
glTranslatef(-200, 25, 0);
       glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(118,-204);
 glVertex2f(115,-204);
 glVertex2f(115,-197);
 glVertex2f(118,-197);
 glEnd();
 glPopMatrix();

glPushMatrix();
glTranslatef(-200, 25, 0);
       glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(128,-204);
 glVertex2f(125,-204);
 glVertex2f(125,-197);
 glVertex2f(128,-197);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(-200, 25, 0);
        glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(138,-204);
 glVertex2f(135,-204);
 glVertex2f(135,-197);
 glVertex2f(138,-197);
 glEnd();
 glPopMatrix();

glPushMatrix();
glTranslatef(-200, 25, 0);
         glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(148,-204);
 glVertex2f(145,-204);
 glVertex2f(145,-197);
 glVertex2f(148,-197);
 glEnd();
     glPopMatrix();

     glPushMatrix();
glTranslatef(-200, 25, 0);
              glColor3ub(255,255,255);
glBegin(GL_QUADS);
 glVertex2f(120,-216);
 glVertex2f(115,-216);
 glVertex2f(115,-214);
 glVertex2f(120,-214);
 glEnd();

    glPopMatrix();

         glPushMatrix();
glTranslatef(-200, 25, 0);
              glColor3ub(255,255,255);
glBegin(GL_QUADS);
 glVertex2f(130,-216);
 glVertex2f(125,-216);
 glVertex2f(125,-214);
 glVertex2f(130,-214);
 glEnd();

    glPopMatrix();

         glPushMatrix();
glTranslatef(-200, 25, 0);
              glColor3ub(255,255,255);
glBegin(GL_QUADS);
 glVertex2f(140,-216);
 glVertex2f(135,-216);
 glVertex2f(135,-214);
 glVertex2f(140,-214);
 glEnd();

    glPopMatrix();
    glPopMatrix();


    //NEW SHIP

            glPushMatrix();
glTranslatef(_run2, 0.0, 0.0);

glPushMatrix();
glTranslatef(180, -15, 0);
       glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(180,-280);
 glVertex2f(115,-280);
 glVertex2f(110,-260);
 glVertex2f(185,-260);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
        glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(125,-260);
 glVertex2f(110,-260);
 glVertex2f(108,-255);
 glVertex2f(122,-255);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
         glColor3ub(255,255,255);
glBegin(GL_QUADS);
 glVertex2f(180,-260);
 glVertex2f(130,-260);
 glVertex2f(130,-240);
 glVertex2f(180,-240);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
          glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(182,-240);
 glVertex2f(128,-240);
 glVertex2f(128,-236);
 glVertex2f(182,-236);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
          glColor3ub(255,255,255);
glBegin(GL_QUADS);
 glVertex2f(175,-236);
 glVertex2f(135,-236);
 glVertex2f(135,-218);
 glVertex2f(175,-218);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
           glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(177,-218);
 glVertex2f(133,-218);
 glVertex2f(133,-214);
 glVertex2f(177,-214);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
            glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(140,-250);
 glVertex2f(135,-250);
 glVertex2f(135,-255);
 glVertex2f(140,-255);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
             glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(150,-250);
 glVertex2f(145,-250);
 glVertex2f(145,-255);
 glVertex2f(150,-255);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
              glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(160,-250);
 glVertex2f(155,-250);
 glVertex2f(155,-255);
 glVertex2f(160,-255);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
               glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(170,-250);
 glVertex2f(165,-250);
 glVertex2f(165,-255);
 glVertex2f(170,-255);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
                glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(143,-228);
 glVertex2f(139,-228);
 glVertex2f(139,-224);
 glVertex2f(143,-224);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
                 glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(151,-228);
 glVertex2f(147,-228);
 glVertex2f(147,-224);
 glVertex2f(151,-224);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
                  glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(159,-228);
 glVertex2f(155,-228);
 glVertex2f(155,-224);
 glVertex2f(159,-224);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
                  glColor3ub(0,0,0);
glBegin(GL_QUADS);
 glVertex2f(167,-228);
 glVertex2f(163,-228);
 glVertex2f(163,-224);
 glVertex2f(167,-224);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(180, -15, 0);
                   glColor3ub(255,0,0);
glBegin(GL_QUADS);
 glVertex2f(182,-272);
 glVertex2f(113,-272);
 glVertex2f(113,-268);
 glVertex2f(182,-268);
 glEnd();
 glPopMatrix();
 glPopMatrix();



    //Plane

            glPushMatrix();
glTranslatef(_run1, 0.0, 0.0);

glPushMatrix();
glTranslatef(-300, 400, 0);
                  glColor3ub(220,220,220);
glBegin(GL_QUADS);
 glVertex2f(180,-150);
 glVertex2f(130,-150);
 glVertex2f(130,-120);
 glVertex2f(180,-120);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(-300, 400, 0);
 glColor3ub(255,0,0);
 glBegin(GL_TRIANGLES);
  glVertex2f(180,-120);
 glVertex2f(200,-135);
 glVertex2f(180,-135);
glEnd();
glPopMatrix();

glPushMatrix();
glTranslatef(-300, 400, 0);
 glColor3ub(255,0,0);
 glBegin(GL_TRIANGLES);
  glVertex2f(180,-135);
 glVertex2f(200,-135);
 glVertex2f(180,-150);
glEnd();
glPopMatrix();

glPushMatrix();
glTranslatef(-300, 400, 0);
              glColor3ub(255,0,0);
glBegin(GL_QUADS);
 glVertex2f(142,-120);
 glVertex2f(130,-120);
 glVertex2f(130,-105);
 glVertex2f(135,-105);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(-300, 400, 0);
               glColor3ub(255,0,0);
glBegin(GL_QUADS);
 glVertex2f(155,-165);
 glVertex2f(140,-165);
 glVertex2f(150,-135);
 glVertex2f(165,-135);
 glEnd();
 glPopMatrix();

 glPushMatrix();
glTranslatef(-300, 400, 0);
                glColor3ub(255,0,0);
glBegin(GL_QUADS);
 glVertex2f(165,-120);
 glVertex2f(150,-120);
 glVertex2f(140,-105);
 glVertex2f(155,-105);
 glEnd();
 glPopMatrix();
 glPopMatrix();


///tree7


glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(70,-20);
    glColor3ub(139,195,74);
    glVertex2f(90,-40);
    glVertex2f(50,-40);
    glEnd();
    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(70,-10);
    glColor3ub(139,195,74);
    glVertex2f(90,-30);
    glVertex2f(50,-30);
    glEnd();

    glColor3ub(178,255,89);
    glBegin(GL_TRIANGLES);
    glVertex2f(70,-10);
    glColor3ub(139,195,74);
    glVertex2f(90,-20);
    glVertex2f(50,-20);
    glEnd();

   glColor3ub(109,76,65);
    glBegin(GL_QUADS);
    glVertex2f(69,-60);

    glVertex2f(71,-60);
    glVertex2f(71,-40);
    glVertex2f(69,-40);
    glEnd();






    glFlush();
    glutSwapBuffers();

}




void update(int value) {

	_run -= 0.7f;
	if (_run > 1000)
    {
        _run -= 1700;
    }

    _run1 += 1.0f;
	if (_run1 > 1000)
    {
        _run1 -= 1300;
    }

    _run2 -= 0.5f;
	if (_run2 > 1000)
    {
        _run2 -= 1300;
    }

     _run3 += 0.2f;
	if (_run3 > 1000)
    {
        _run3 -= 1700;
    }

    if(onOff){
	_ang_tri += 2.5f;
	if (_ang_tri > 1000){
		_ang_tri = 1300;
	}
	 }

	glutPostRedisplay(); //Tell GLUT that the display has changed
	glutTimerFunc(25, update, 0);

}

void Night(int value){

if(night){



    glClearColor(0.0,0.0,0.0,0.0);
	glutPostRedisplay();
    glutTimerFunc(5, Night, 0);
    glFlush();

}
}


void Rain(int value){

if(rainday){

    _rain += 0.01f;

    glBegin(GL_POINTS);
    for(int i=1;i<=1000;i++)
    {
        int x=-rand(),y=-rand();
        x%=1000; y%=1000;
        glBegin(GL_LINES);
        glColor3f(1.0, 1.0, 1.0);
        glVertex2f(x,y);
        glVertex2f(x+5,y+5);

        x=rand(),y=rand();
        x%=1000; y%=1000;
        glBegin(GL_LINES);
        glColor3f(1.0, 1.0, 1.0);
        glVertex2f(x,y);
        glVertex2f(x+5,y+5);

        x=-rand(),y=rand();
        x%=1000; y%=1000;
        glBegin(GL_LINES);
        glColor3f(1.0, 1.0, 1.0);
        glVertex2f(x,y);
        glVertex2f(x+5,y+5);

        x=rand(),y=-rand();
        x%=1000; y%=1000;
        glBegin(GL_LINES);
        glColor3f(1.0, 1.0, 1.0);
        glVertex2f(x,y);
        glVertex2f(x+5,y+5);
        glEnd();
    }


	glutPostRedisplay();
	glutTimerFunc(5, Rain, 0);

    glFlush();

}
}




void myKeyboard(unsigned char key, int x, int y){
	switch (key)
	{
	    case 'n':
        night = true;
        Night(_nt);
        break;

    case 'b':
        night = false;
        glClearColor(0.0,0.5,0.8,1.0);
        break;


    case 'r':
        rainday = true;
        Rain(_rain);
        sndPlaySound("River.wav",SND_ASYNC|SND_LOOP);
        //sndPlaySound("River.wav",SND_MEMORY|SND_ASYNC);
        break;

    case 'e':
        rainday = false;
		sndPlaySound(NULL,SND_ASYNC);
        break;


    case 27:     // ESC key
        exit(0);
        break;

	default:
	break;
	}
}


int main(int argc,char **argv)
{
   cout << endl << "***********  View Of A City  ********************" << endl << endl;



    cout << "Press N : For Night " << endl << endl;
    cout << "Press B : For Day" << endl << endl;

    cout << "Press R : For Rain " << endl << endl;
    cout << "Press E : For Stop Rain" << endl << endl;

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE| GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1200, 750);
	glutCreateWindow(" View");     // creating the window
	//glutFullScreen();       // making the window full screen
	//glutInitWindowPosition(0,0);
	glutDisplayFunc(display);
	glutKeyboardFunc(myKeyboard);
	glutTimerFunc(25, update, 0);
	init();
	glutMainLoop();
	return 0;
}

